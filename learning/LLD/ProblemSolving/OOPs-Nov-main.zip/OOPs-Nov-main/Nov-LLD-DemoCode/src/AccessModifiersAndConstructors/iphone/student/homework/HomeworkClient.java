package AccessModifiersAndConstructors.iphone.student.homework;

import AccessModifiersAndConstructors.iphone.student.Student;

public class HomeworkClient {
    public static void main(String[] args) {
        Student s = new Student();
    }
}
