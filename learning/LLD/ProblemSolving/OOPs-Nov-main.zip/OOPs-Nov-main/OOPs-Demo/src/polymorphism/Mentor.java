package polymorphism;

public class Mentor extends User{

    public Mentor(String uName, String uEmail, String uPassword) {
        super(uName, uEmail, uPassword);
    }

}
