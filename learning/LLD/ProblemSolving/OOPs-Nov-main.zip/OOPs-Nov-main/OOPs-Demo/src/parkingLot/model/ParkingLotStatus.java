package parkingLot.model;

public enum ParkingLotStatus {
    OPEN, CLOSED;
}
