package designPatterns.factory.components.button;

public class AndroidButton implements Button{
}
