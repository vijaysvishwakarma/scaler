package designPatterns.factory.components.button;

public class WindowsButton implements Button{
}
