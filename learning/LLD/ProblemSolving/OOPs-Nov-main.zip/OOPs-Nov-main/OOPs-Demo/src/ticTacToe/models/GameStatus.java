package ticTacToe.models;

public enum GameStatus {
    DRAW,
    ENDED,
    IN_PROGRESS;
}
