package ticTacToe.models;

public enum CellState {
    EMPTY,
    BLOCKED,
    FILLED;
}
