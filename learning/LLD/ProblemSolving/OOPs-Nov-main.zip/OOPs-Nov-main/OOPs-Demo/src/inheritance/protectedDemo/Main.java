package inheritance.protectedDemo;

public class Main {
    public static void main(String[] args) {
        C c = new C();
        c.printValues();
    }
}
