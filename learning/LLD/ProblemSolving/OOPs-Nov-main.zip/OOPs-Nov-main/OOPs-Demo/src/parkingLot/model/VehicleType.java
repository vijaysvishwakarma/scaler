package parkingLot.model;

public enum VehicleType {
    LARGE,MEDIUM,SMALL,ELECTRIC;
}
