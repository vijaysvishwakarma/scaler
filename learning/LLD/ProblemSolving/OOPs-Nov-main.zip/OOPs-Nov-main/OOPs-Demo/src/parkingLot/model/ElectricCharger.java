package parkingLot.model;

public class ElectricCharger extends BaseModel{
}
