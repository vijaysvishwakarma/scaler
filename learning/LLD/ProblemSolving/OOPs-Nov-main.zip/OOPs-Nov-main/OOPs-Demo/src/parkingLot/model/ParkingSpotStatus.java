package parkingLot.model;

public enum ParkingSpotStatus {
    AVAILABLE,
    OCCUPIED,
    IN_MAINTENANCE;
}
