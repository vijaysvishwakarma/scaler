package parkingLot.service;

import parkingLot.model.Gate;

public interface GateService {
    Gate getGate(Long gateId);
}
