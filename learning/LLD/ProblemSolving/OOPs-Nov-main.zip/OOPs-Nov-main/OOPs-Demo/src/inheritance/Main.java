package inheritance;

import inheritance.demoPackage.B;

public class Main {
    public static void main(String[] args) {
        Student s = new Student();
        s.name = "Bhargava";
        s.psp = 98;
        s.age = 24;
        s.login();

        B b = new B();

    }
}
