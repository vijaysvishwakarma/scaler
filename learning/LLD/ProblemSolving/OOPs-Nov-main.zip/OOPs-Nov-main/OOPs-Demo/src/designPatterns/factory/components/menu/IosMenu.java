package designPatterns.factory.components.menu;

public class IosMenu implements Menu{
}
