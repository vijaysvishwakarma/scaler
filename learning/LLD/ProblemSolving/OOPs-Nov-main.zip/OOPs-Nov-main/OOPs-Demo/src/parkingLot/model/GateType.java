package parkingLot.model;

public enum GateType {
    ENTRY,EXIT;
}
