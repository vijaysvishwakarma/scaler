package parkingLot.model;

public enum PaymentMode {
    CASH,ONLINE,BALANCE_CARD;
}
