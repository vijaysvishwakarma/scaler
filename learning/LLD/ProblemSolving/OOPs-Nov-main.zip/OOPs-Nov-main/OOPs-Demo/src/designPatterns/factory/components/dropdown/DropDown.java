package designPatterns.factory.components.dropdown;

public interface DropDown {
}
