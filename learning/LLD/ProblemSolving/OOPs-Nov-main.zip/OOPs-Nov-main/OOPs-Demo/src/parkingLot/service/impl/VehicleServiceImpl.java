package parkingLot.service.impl;

import parkingLot.model.Vehicle;
import parkingLot.model.VehicleType;
import parkingLot.service.VehicleService;

public class VehicleServiceImpl implements VehicleService {
    //TODO: create a vehicleRepository and use that inside VehicleServiceImpl
    @Override
    public Vehicle getVehicle(String vehicleNumber) {
        return null;
    }

    @Override
    public Vehicle registerVehicle(String vehicleNumber, VehicleType vehicleType) {
        return null;
    }
}
