package AccessModifiersAndConstructors.iphone.student;

public class StudentClient {
    public static void main(String[] args) {
        Student s1 = new Student("Santhosh", 28, 98);

        Student s3 = new Student("Krishna", 27, 99);

        School s = new School("ABC", "Stree A, City B", 10);
    }
}
