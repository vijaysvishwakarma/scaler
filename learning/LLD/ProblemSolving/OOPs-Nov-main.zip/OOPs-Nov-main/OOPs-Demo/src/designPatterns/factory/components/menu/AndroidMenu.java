package designPatterns.factory.components.menu;

public class AndroidMenu implements Menu{
}
