package polymorphism.UpDownCasting;

public class Animal {
    public String name;

    public void eats(){
        System.out.println("Animal is eating");
    }

    public void breathes(){
        System.out.println("Animal is breathing");
    }
}
