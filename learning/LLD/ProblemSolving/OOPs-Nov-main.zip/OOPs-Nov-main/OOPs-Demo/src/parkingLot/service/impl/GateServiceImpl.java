package parkingLot.service.impl;

import parkingLot.model.Gate;
import parkingLot.service.GateService;

public class GateServiceImpl implements GateService {
    //TODO: create a repository for gate, and use that here
    @Override
    public Gate getGate(Long gateId) {
        return null;
    }
}
