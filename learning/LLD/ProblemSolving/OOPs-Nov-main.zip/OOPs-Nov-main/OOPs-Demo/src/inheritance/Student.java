package inheritance;

public class Student extends User {
    public int age;
    public double psp;


}
