package designPatterns.adapter.thirdparty.banks;

public class ICICIApi {
    //contains methods for operations via ICICI
}
