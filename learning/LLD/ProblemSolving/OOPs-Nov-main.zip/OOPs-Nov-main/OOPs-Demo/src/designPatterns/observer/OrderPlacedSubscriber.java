package designPatterns.observer;

public interface OrderPlacedSubscriber {
    ReturnData orderPlaceEvent();
}
