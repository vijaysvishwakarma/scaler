package designPatterns.factory.components.button;

public interface Button {
}
