package designPatterns.factory.components.menu;

public interface Menu {
}
