package designPatterns.factory.components.button;

public class IosButton implements Button{
}
