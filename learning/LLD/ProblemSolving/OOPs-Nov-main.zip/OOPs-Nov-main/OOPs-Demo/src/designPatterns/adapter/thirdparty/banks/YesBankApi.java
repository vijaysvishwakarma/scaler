package designPatterns.adapter.thirdparty.banks;

public class YesBankApi {
}
