package designPatterns.factory;

public enum SupportedPlatform {
    ANDROID, IOS, WINDOWS;
}
