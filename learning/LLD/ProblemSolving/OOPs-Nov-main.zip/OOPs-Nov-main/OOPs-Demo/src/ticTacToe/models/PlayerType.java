package ticTacToe.models;

public enum PlayerType {
    HUMAN,
    BOT;
}
