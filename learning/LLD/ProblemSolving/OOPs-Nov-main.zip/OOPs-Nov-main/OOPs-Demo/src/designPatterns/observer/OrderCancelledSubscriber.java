package designPatterns.observer;

public interface OrderCancelledSubscriber {
    ReturnData orderCancelledEvent();
}
