package parkingLot.model;

public enum BillStatus {
    PAID,UNPAID;
}
