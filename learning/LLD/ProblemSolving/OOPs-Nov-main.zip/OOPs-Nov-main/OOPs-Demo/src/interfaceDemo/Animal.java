package interfaceDemo;

public interface Animal {
    void walk();
    void run();
    void eat();
}
