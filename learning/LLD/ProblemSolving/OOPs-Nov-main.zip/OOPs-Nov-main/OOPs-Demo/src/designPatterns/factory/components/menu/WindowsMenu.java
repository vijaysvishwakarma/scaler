package designPatterns.factory.components.menu;

public class WindowsMenu implements Menu{
}
