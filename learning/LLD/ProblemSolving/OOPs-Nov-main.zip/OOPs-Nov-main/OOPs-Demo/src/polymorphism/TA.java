package polymorphism;

public class TA extends User{
    public TA(String uName, String uEmail, String uPassword) {
        super(uName, uEmail, uPassword);
    }
}
