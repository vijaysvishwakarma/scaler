package parkingLot.strategy.spotAssignmentStrategy;

import parkingLot.model.Gate;
import parkingLot.model.ParkingSpot;
import parkingLot.model.VehicleType;

public class RandomSpotAssignmentStrategy implements SpotAssignmentStrategy{
    @Override
    public ParkingSpot assign(VehicleType vehicleType, Gate gate) {
        /* TODO : complete this code
            ParkingLot parkingLot = ParkingLotRepository.getParkingLot();
            List<ParkingSpot> parkingSpots;
            for(ParkingFloor p : parkingLot.getFloors()){
                parkingSpot.add(p.getSpots());
            }
            for(ParkingSpot parkingSpot : parkingSpots){
                //take a spot is available, same as vehicletype and return the spot
            }
            // update the parkingSpot as not available
         */
        return null;
    }
}
