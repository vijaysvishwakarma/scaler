package abstractDemo;

public class Main {
    public static void main(String[] args) {
        Animal a = new Dog("Tuffi", 2 );
        a.breathe();
        a.walk();
    }
}
