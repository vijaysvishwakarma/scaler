package parkingLot.model;

public enum PaymentStatus {
    SUCCESS, FAILURE, IN_PROGRESS;
}
