package AccessModifiersAndConstructors.iphone.school;

import AccessModifiersAndConstructors.iphone.student.Student;

public class SchoolClient {
    public static void main(String[] args) {
        Student s = new Student();
    }
}
